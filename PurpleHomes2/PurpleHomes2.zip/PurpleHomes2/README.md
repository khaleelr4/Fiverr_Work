# PurpleHomes2
This is the Purple Home logo 2

![Alt text](PurpleHomes2.png?raw=true "PurpleHome Logo 2")